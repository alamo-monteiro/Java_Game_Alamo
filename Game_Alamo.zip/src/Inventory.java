import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.util.ArrayList;

/// Classe Inventory
class Inventory {
    private final ArrayList<Item> items;


    public Inventory() {
        this.items = new ArrayList<>();
    }


    public void addItem(Item item) {
        items.add(item);
    }


    public ArrayList<Item> getItems() {
        return items;
    }
}

