import java.awt.*;

// Classe Item
class Item extends SolidSprite {
    private final String name;


    public Item(double x, double y, Image image, double width, double height, String name) {
        super(x, y, image, width, height);
        this.name = name;
    }


    public String getName() {
        return name;
    }
}

