public interface Engine {
    public void update();
}
