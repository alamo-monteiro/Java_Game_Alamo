import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

class InventoryPanel extends JPanel {
    private final ArrayList<Item> items; // List of items to be displayed in the inventory

    // Constructor to initialize the inventory panel
    public InventoryPanel(ArrayList<Item> items) {
        this.items = items;
        setBackground(new Color(0, 0, 0, 200)); // Semi-transparent black background
        setLayout(null); // Disable automatic layout to manually control item positioning
        setVisible(false); // Inventory starts invisible by default
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // Clears the panel before custom drawing

        // Draw the inventory title
        g.setColor(Color.WHITE); // Set text color to white
        g.setFont(new Font("Arial", Font.BOLD, 14)); // Set font to Arial, bold, size 14
        g.drawString("Inventory:", 10, 20); // Draw the title at the top-left corner

        // Draw the items in the inventory
        int x = 10, y = 40; // Initial coordinates for the first item
        for (Item item : items) {
            g.drawImage(item.image, x, y, 32, 32, null); // Draw the item's image (32x32 pixels)
            g.drawString(item.getName(), x, y + 45); // Draw the item's name below its image
            x += 50; // Horizontal spacing between items
            if (x > getWidth() - 50) { // If the current row is full, move to the next row
                x = 10; // Reset x-coordinate for the new row
                y += 60; // Move down to the next row
            }
        }
    }

    // Updates the inventory with the collected items
    public void updateInventory(ArrayList<Item> collectedItems) {
        items.clear(); // Clear the current list of items
        items.addAll(collectedItems); // Add all collected items to the inventory
        repaint(); // Redraw the panel to reflect the updated items
    }
}
