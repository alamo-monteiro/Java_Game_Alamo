import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.util.ArrayList;

class GameEngine implements Engine, KeyListener {
    private final DynamicSprite hero; // The main character controlled by the player
    private final Inventory inventory; // Manages the player's inventory items
    private ArrayList<Item> itemsOnMap; // List of items currently available on the map
    private final JPanel inventoryPanel; // GUI panel displaying the inventory
    private boolean isInventoryVisible = false; // Tracks whether the inventory is currently visible
    private final RenderEngine renderEngine; // Reference to the rendering engine
    private final ArrayList<Displayable> fixedElements; // Fixed elements such as the hero and terrain

    // Constructor to initialize the game engine components
    public GameEngine(DynamicSprite hero, JPanel inventoryPanel, RenderEngine renderEngine) {
        this.hero = hero; // Sets the main character
        this.inventory = new Inventory(); // Initializes an empty inventory
        this.itemsOnMap = new ArrayList<>(); // Initializes an empty list of items on the map
        this.inventoryPanel = inventoryPanel; // Sets the inventory panel
        this.renderEngine = renderEngine; // Sets the rendering engine
        this.fixedElements = new ArrayList<>(); // Initializes the list of fixed elements
        this.fixedElements.add(hero); // Adds the hero as a fixed element in the game
    }

    // Updates the list of items currently on the map
    public void setItemsOnMap(ArrayList<Item> itemsOnMap) {
        this.itemsOnMap = itemsOnMap;
    }

    // Adds additional fixed elements to the list (e.g., terrain or static objects)
    public void setFixedElements(ArrayList<Displayable> fixedElements) {
        this.fixedElements.addAll(fixedElements);
    }

    // Checks if the game is paused (based on inventory visibility)
    public boolean isPaused() {
        return isInventoryVisible;
    }

    // Updates the game state, including item collection and render list
    @Override
    public void update() {
        ArrayList<Item> collectedItems = new ArrayList<>(); // Tracks items collected by the hero

        // Checks for collisions between the hero and items on the map
        for (Item item : itemsOnMap) {
            if (hero.getHitBox().intersects(item.getHitBox())) {
                inventory.addItem(item); // Adds the item to the inventory
                collectedItems.add(item); // Marks the item for removal
                System.out.println("Collected item: " + item.getName()); // Logs the collected item
            }
        }

        // Removes collected items from the map
        itemsOnMap.removeAll(collectedItems);

        // Updates the inventory panel display if it is a specialized inventory panel
        if (inventoryPanel instanceof InventoryPanel) {
            ((InventoryPanel) inventoryPanel).updateInventory(inventory.getItems());
        }

        // Updates the render list in the RenderEngine
        ArrayList<Displayable> updatedRenderList = new ArrayList<>(fixedElements); // Keeps fixed elements
        updatedRenderList.addAll(itemsOnMap); // Adds remaining items on the map
        renderEngine.updateRenderList(updatedRenderList); // Updates the render engine with the new list
    }

    // Unused KeyListener method (required for implementation)
    @Override
    public void keyTyped(KeyEvent e) {}

    // Handles key presses for character movement and inventory visibility
    @Override
    public void keyPressed(KeyEvent e) {
        if (!isPaused()) { // If the game is not paused
            switch (e.getKeyCode()) {
                case KeyEvent.VK_UP -> hero.setDirection(Direction.NORTH); // Moves the hero north
                case KeyEvent.VK_DOWN -> hero.setDirection(Direction.SOUTH); // Moves the hero south
                case KeyEvent.VK_LEFT -> hero.setDirection(Direction.WEST); // Moves the hero west
                case KeyEvent.VK_RIGHT -> hero.setDirection(Direction.EAST); // Moves the hero east
            }
        }

        // Toggles inventory visibility when the 'I' key is pressed
        if (e.getKeyCode() == KeyEvent.VK_I) {
            isInventoryVisible = !isInventoryVisible; // Toggles the state
            if (inventoryPanel != null) {
                inventoryPanel.setVisible(isInventoryVisible); // Updates the visibility of the inventory panel
            }
        }
    }

    // Unused KeyListener method (required for implementation)
    @Override
    public void keyReleased(KeyEvent e) {}
}








