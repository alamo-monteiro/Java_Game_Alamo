import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class RenderEngine extends JPanel {
    private ArrayList<Displayable> renderList = new ArrayList<>();

    public RenderEngine() {
        // Construtor padrão
    }

    public void addToRenderList(Displayable displayable) {
        renderList.add(displayable);
    }

    public void addToRenderList(ArrayList<Displayable> displayables) {
        renderList.addAll(displayables);
    }

    public void updateRenderList(ArrayList<Displayable> newRenderList) {
        renderList = new ArrayList<>(newRenderList); // Substitui a lista atual
        repaint(); // Redesenha o mapa
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Displayable displayable : renderList) {
            displayable.draw(g);
        }
    }
}

