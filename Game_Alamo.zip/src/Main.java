import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;




public class Main {

    JFrame displayZoneFrame;
    RenderEngine renderEngine;
    GameEngine gameEngine;
    PhysicEngine physicEngine;

    public Main() throws Exception {
        // Configuração da janela de exibição
        displayZoneFrame = new JFrame("Java Labs");
        displayZoneFrame.setSize(400, 600);
        displayZoneFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Carrega o personagem principal (herói)
        DynamicSprite hero = new DynamicSprite(150, 300,
                ImageIO.read(new File("C:\\Users\\alamo\\Downloads\\FISE_2024_2025_Dungeon_Crawler-master\\FISE_2024_2025_Dungeon_Crawler-master\\img\\heroTileSheetLowRes.png")), 48, 50);

        // Inventory Panel
        InventoryPanel inventoryPanel = new InventoryPanel(new ArrayList<>());
        inventoryPanel.setBounds(50, 50, 300, 400);
        inventoryPanel.setVisible(false); // Inventory starts invisible
        displayZoneFrame.add(inventoryPanel);


        renderEngine = new RenderEngine();
        physicEngine = new PhysicEngine();
        gameEngine = new GameEngine(hero, inventoryPanel, renderEngine);

        //KeyListener para controle de personagem
        displayZoneFrame.addKeyListener(gameEngine);
        displayZoneFrame.setFocusable(true);

        // Inicializa os timers para atualizações de renderização e física
        Timer renderTimer = new Timer(50, (time) -> {
            if (!gameEngine.isPaused()) {
                renderEngine.repaint(); // update the rendering
            }
        });
        Timer gameTimer = new Timer(50, (time) -> {
            if (!gameEngine.isPaused()) {
                gameEngine.update(); // Atualiza o jogo
            }
        });
        Timer physicTimer = new Timer(50, (time) -> {
            if (!gameEngine.isPaused()) {
                physicEngine.update(); // Atualiza a física
            }
        });

        // start the timers
        renderTimer.start();
        gameTimer.start();
        physicTimer.start();

        // Adiciona o motor de renderização à janela de exibição
        displayZoneFrame.getContentPane().add(renderEngine);
        displayZoneFrame.setVisible(true);

        // Carrega o nível do playground
        Playground level = new Playground("C:\\Users\\alamo\\Downloads\\FISE_2024_2025_Dungeon_Crawler-master\\FISE_2024_2025_Dungeon_Crawler-master\\data\\level1.txt");

        // Integra os sprites do playground ao RenderEngine e PhysicEngine
        renderEngine.addToRenderList(level.getSpriteList());
        renderEngine.addToRenderList(hero);
        physicEngine.addToMovingSpriteList(hero);
        physicEngine.setEnvironment(level.getSolidSpriteList());

        // Define os elementos fixos no GameEngine
        ArrayList<Displayable> fixedElements = new ArrayList<>();
        fixedElements.addAll(level.getSpriteList());
        fixedElements.add(hero);
        gameEngine.setFixedElements(fixedElements);



        // Creating items on the map
        Item icon1 = new Item(200, 250,
                ImageIO.read(new File("C:\\Users\\alamo\\Downloads\\FISE_2024_2025_Dungeon_Crawler-master\\FISE_2024_2025_Dungeon_Crawler-master\\img\\icon1.png")), 32, 32, "Icon1");
        Item icon2 = new Item(300, 350,
                ImageIO.read(new File("C:\\Users\\alamo\\Downloads\\FISE_2024_2025_Dungeon_Crawler-master\\FISE_2024_2025_Dungeon_Crawler-master\\img\\icon2.png")), 32, 32, "Icon2");
        Item icon3 = new Item(250, 400,
                ImageIO.read(new File("C:\\Users\\alamo\\Downloads\\FISE_2024_2025_Dungeon_Crawler-master\\FISE_2024_2025_Dungeon_Crawler-master\\img\\icon3.png")), 32, 32, "Icon3");

        ArrayList<Item> itemsOnMap = new ArrayList<>();
        itemsOnMap.add(icon1);
        itemsOnMap.add(icon2);
        itemsOnMap.add(icon3);

        // Integra os itens ao RenderEngine e ao GameEngine
        ArrayList<Displayable> displayableItems = new ArrayList<>(itemsOnMap); // Conversão manual para Displayable
        renderEngine.addToRenderList(displayableItems);
        gameEngine.setItemsOnMap(itemsOnMap);
    }

    public static void main(String[] args) throws Exception {
        new Main();
    }
}

